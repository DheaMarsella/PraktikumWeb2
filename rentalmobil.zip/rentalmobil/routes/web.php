<?php
namespace App\http\controllers;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/welcomes', function() {
    echo "Selamat datang di laravel";
}); 

Route::get('/greeting', function() {
    return view('greeting');
});

Route::get('/mobil', function() {
    return view('index');
});

Route::get('/mobil', [MobilController::class,'index']);
Route::get('/mobil/create',[MobilController::class, 'create']);
Route::post('/mobil/store',[MobilController::class, 'store']);
